<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];

$id=$_POST['id'];

$queryprodel = "delete from DiscountFocCustomer where cusid='$id'";
$stmt = sqlsrv_query($con,$queryprodel);

}
?>