<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
  $h_id=$_POST['code'];
  $reason=$_POST['reason'];
  
    $statusupdate = "UPDATE DiscountFocHeader set statusid='1',reason='$reason' where id='$h_id'";

$stmt = sqlsrv_query( $con, $statusupdate );

  


?>