<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];
$code=$_POST['code'];
$coderand=$_POST['coderand'];
$datef=$_POST['datef'];
$disctype=$_POST['disctype'];
$descr=$_POST['descr'];
$dateto=$_POST['dateto'];
$userid=$_POST['userid'];
$created_on= date('Y-m-d');
$created_time=date('h:i:s');


$sql = "update DiscountFocHeader set description='$descr',datefrom ='$datef',dateto='$dateto',userid='$userid',discountype='$disctype' where id='$code'";
$stmt = sqlsrv_query( $con, $sql );

}

?>