<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];

$code=$_GET['code'];

if($code!=""){

  $querycusto = " select c.focheaderid , c.cuscode as 'code' , c.cusid as 'id', i.Description as 'name' from DiscountFocCustomer c inner join customer i on c.cuscode=i.Code where c.focheaderid='$code'"; 
  }
  else{

    $querycusto = "select c.focheaderid , c.cuscode as 'code' , i.Description as 'name' from DiscountFocCustomer c inner join customer i on c.cuscode=i.Code";
	}
	
	$stmt = sqlsrv_query($con,$querycusto );
	while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ){
	 echo '<tr>
	 <td> <button type="button" onclick=deletecus('.$row["id"].') class="btn btn-danger" style="background-color:red;">x</button></td>
           <td>'.$row['code'].'</td>
            <td>'.$row['name'].'</td>
			 
            </tr>';
	
	}
	
	}
?>
<script>
  function deletecus(id){
        //alert(id);
		var code="<?php echo $code; ?>";
		//alert(code);
        
        $.ajax({

            url:'delete/deletecus.php',
            method:'POST',
            data:{id:id},
            success:function(){
				alert("Record deleted Successfully");
                $("#cuscontent").load("get/foccus.php?code="+code);

            }
        })





    }
  </script>