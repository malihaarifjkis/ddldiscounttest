<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];

$code=$_GET['code'];

if($code!=""){

  $querypro = " select p.proid as 'id',p.focheaderid , p.procode as 'code' ,p.originalprice as 'price',p.discountprice as 'priceexcl',p.discountper as 'disc', i.Description_1 as 'name' from DiscountFocProduct p inner join item i on p.procode=i.Code where p.focheaderid='$code'";  }
  else{

    $querypro = "select p.focheaderid , p.procode as 'code', i.Description_1 as 'name' from DiscountFocProduct p inner join item i on p.procode=i.Code";
	}
	
	$stmt = sqlsrv_query($con,$querypro );
	while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ){
	 echo '<tr>
	 <td> <button type="button" onclick=deletepro('.$row["id"].') class="btn btn-danger" style="background-color:red;">x</button></td>
           <td>'.$row['name'].'</td>
            <td>'.$row['code'].'</td>
			 <td>'.$row['price'].'</td>
			  <td>'.$row['disc'].'</td>
			   <td>'.$row['priceexcl'].'</td>
            </tr>';
	
	}
	
	}
	
	
?>

<script>
  function deletepro(id){
        //alert(id);
		var code="<?php echo $code; ?>";
		//alert(code);
        
        $.ajax({

            url:'delete/deletepro.php',
            method:'POST',
            data:{id:id},
            success:function(){
				alert("Record deleted Successfully");
               $("#buycontent").load("get/focproitem.php?code="+code); 

            }
        })





    }
  </script>