<?php 
require_once "../connection.php";

session_start();


if(isset($_POST['username']) && isset($_POST['password'])){
	$name=$_POST['username'];
	$pass=$_POST['password'];
	



	$queryname = "SELECT COUNT(username) as total,password,username FROM user WHERE username = ? AND password = ?";
	$stmt = $GLOBALS['conn']->prepare($queryname);
	$stmt->bind_param("ss", $name,$pass);
	
	$stmt->execute();
	$result1 = $stmt->get_result();
	$row = $result1->fetch_assoc();
	$peopleid=$row['total'];
	$chkpass=$row['password'];

	if($chkpass!==$pass){
		 echo  '<script>alert("wrong password kindly reset your password !")
		 window.location.href="../index.php";
		 </script>';

	}

	else {

	if($peopleid==1){

		$sessionid = session_id();

		$queryupdate = "UPDATE user SET session_id = ? WHERE username = ? AND password = ?";
		$stmt = $GLOBALS['conn']->prepare($queryupdate);
		$stmt->bind_param("sss", $sessionid,$name,$pass);
		$stmt->execute();
		$_SESSION["username"]=$name;
 		header("Location:../newscreen.php");
 		exit;

	}

	else{

	header("Location:../index.php");
}

}

}




?>