<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];

$cusnames=$_POST['cusnames'];
$code=$_POST['code'];

echo $cusnames;
$sql = "insert into DiscountFocCustomer (focheaderid,cuscode) values ('$code','$cusnames')";
$stmt = sqlsrv_query( $con, $sql );

}

?>