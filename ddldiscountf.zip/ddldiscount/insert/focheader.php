<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];

$coderand=$_POST['coderand'];
$datef=$_POST['datef'];
$disctype=$_POST['disctype'];
$descr=$_POST['descr'];
$dateto=$_POST['dateto'];
$userid=$_POST['userid'];
$created_on= date('Y-m-d');
$created_time=date('h:i:s');


$sql = "insert into DiscountFocHeader 
(focheaderid,description,datefrom,dateto,userid,statusid,createddate,discountype) values ('$coderand','$descr','$datef','$dateto','$userid','0','$created_on','$disctype')";
$stmt = sqlsrv_query( $con, $sql );

}

?>