<?php
session_start();
include "../connection.php";
include "../mssqlconnection.php";
if($_SESSION["username"]==true){
$name=$_SESSION["username"];

$pname=$_POST['pnames'];
$code=$_POST['code'];
$discper=$_POST['discper'];
$prices=$_POST['prices'];
$discprice=$_POST['discprice'];


echo $pname;
$sql = "insert into DiscountFocProduct (focheaderid,procode,originalprice,discountprice,discountper) values ('$code','$pname','$prices','$discprice','$discper')";
$stmt = sqlsrv_query( $con, $sql );

}

?>